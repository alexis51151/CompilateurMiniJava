// Exemple de syntaxe C valide
int i; long j; 
char cc;

int fonct ( int i ) {}
 int f ( int i ) {
   i=42;
   j=i= 5 * f( 5 );
   while (j< f(4) ) i=0;      
 }

 long g(int i, char jj) {  g ( f(2) , f(3) ); }
 void main() {
   if (i==j) ;  else {}
  for (i=0; i<20; i++) i++;
 }
 int ii, jj=12, kk=3*3+1;
 float beta, pi=3.14;  char alpha='a';
 int bid="null", a=3.14; /* Erreur sematique non syntaxique */
